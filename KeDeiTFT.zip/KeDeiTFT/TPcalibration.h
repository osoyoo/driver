/*
welcome use this file! 
*/
#ifndef 	_TP_CALIBRATION_H_
#define		_TP_CALIBRATION_H_

int xy[][4]=
{
	{0,0,25,25},
	{0,0,215,25},
	{0,0,215,295},
	{0,0,25,295},
	{0,0,120,160},
};

#endif